# tempmanager

A tray temperature readout for Windows. Left-click the tray icon for a flyout
with current readings, a history chart, and a sampling-interval slider.

Written in Rust against raw Win32 — no UI framework, no runtime, no service.

## What it measures

| Source | How | Requirements |
|---|---|---|
| NVIDIA GPU | NVML (`nvml.dll`, ships with the display driver) | None |
| NVMe / SATA drives | `IOCTL_STORAGE_QUERY_PROPERTY` | None |
| AMD Ryzen die temp | AMD Ryzen Master Monitoring SDK | SDK installed + elevated |
| AMD Ryzen die temp (fallback) | SMU registers over PCI config space | WinRing0 + Memory Integrity off |

GPU and drive temperatures work immediately with no elevation and nothing
installed.

CPU temperature goes through AMD's own WHQL-signed driver, which loads happily
with Memory Integrity enabled. The catch is that AMD's `Platform.dll` will not
initialise for a non-elevated caller, so the app needs an elevated token to read
it — see [SETUP.md](SETUP.md) for the two ways to arrange that, including a
logon task that starts elevated without a UAC prompt.

The CPU sensor sits behind a `CpuBackend` trait, so the SDK path and the direct
register path are interchangeable and the rest of the app is indifferent to
which one is live.

## Measured footprint

On the development machine (Ryzen 7 9800X3D, RTX 5080, Windows 11), idle at the
default 30 s interval:

```
Working set    1.8 MB
Threads        4  (1 ours, 3 created by Win32/DWM)
CPU time       0.031 s total, unchanged across sample ticks
Binary         332 KB, no dependencies beyond system DLLs
```

## Where the efficiency comes from

- **The sampling rate follows attention.** While the flyout is open the app
  samples every second so the chart moves in real time; the moment it closes,
  the timer drops back to the configured interval. Nobody is watching a chart
  that is not on screen, so there is nothing to pay for. The live rate is
  clamped to whatever the active backend tolerates — AMD's SDK documents that
  `GetCPUParameters` degrades if polled faster than 1 Hz, so 1 s is the floor.
- **The time axis stays honest across rate changes.** Because the cadence
  varies, each sample stores the interval it was taken at (two bytes), and the
  chart sums those to label the span. A window that is part background samples
  and part live samples reports the true elapsed time rather than assuming the
  current rate applied throughout.
- **One thread, no sampling loop.** Sampling is driven by a coalescable timer
  on the existing message loop. `SetCoalescableTimer` with a 10% tolerance lets
  the kernel align our wakeup with timers already scheduled, so an idle machine
  is not woken solely for us.
- **`GetMessageW` blocks.** Between samples the process is genuinely parked, not
  polling, so it accrues no measurable CPU time.
- **No allocation on the sample path.** Channels are fixed at startup and
  history lives in preallocated ring buffers (`i16` tenths of a degree, 1200
  samples per channel — about 2.4 KB each), so the working set is flat over
  uptime.
- **The chart is only drawn while the flyout is visible.**
- **The tray icon is only re-rendered when the displayed number or its colour
  actually changes.**
- **The flyout window is created on first click,** not at startup, so a session
  that never opens it never pays for DWM composition state.
- **Working set is trimmed** after startup and whenever the flyout closes.

## Usage

Left-click the tray icon to open the flyout. Drag the slider to change the
sampling interval — it snaps to sensible stops from 1 s to 5 min and saves
immediately.

Right-click for: which sensor the tray icon tracks (hottest / CPU / GPU),
Celsius↔Fahrenheit, Start with Windows, and Exit.

Settings live in `%APPDATA%\tempmanager\config.ini`.

### Diagnostics

```bash
tempmanager.exe --probe
```

Samples every sensor once and writes `probe.txt` next to the executable. Useful
for checking what is actually detected — the app is a GUI-subsystem binary, so
it has no console to print to.

```bash
tempmanager.exe --shot
```

Renders the flyout offscreen to `popup.bmp` for checking layout.

## Building

Needs the Rust GNU toolchain (no Visual Studio required):

```bash
rustup toolchain install stable-x86_64-pc-windows-gnu
```

```bash
cargo build --release
```

Output lands at `target/x86_64-pc-windows-gnu/release/tempmanager.exe`. The
target is pinned in `.cargo/config.toml`, so a bare `cargo build` picks it up.

Note: the executable locks itself while running — stop it before rebuilding.

## Layout

```
src/
  main.rs            entry point, message loop, tray interaction, context menu
  app.rs             shared state, sampling, tray text
  popup.rs           the flyout window: layout, painting, slider input
  graph.rs           the history chart (2x supersampled GDI)
  tray.rs            tray icon rendering (text -> DIB -> HICON)
  history.rs         fixed-capacity ring buffers
  config.rs          settings load/save
  theme.rs           colours
  sensors/
    mod.rs           discovery and sampling
    nvml.rs          NVIDIA GPU
    storage.rs       NVMe / SATA drives
    amd.rs           AMD Zen die temperature decoding
    driver.rs        ring-0 PCI config access client
```
