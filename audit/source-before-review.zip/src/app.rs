//! Shared application state.
//!
//! One instance lives for the process lifetime and is reached from both window
//! procedures through GWLP_USERDATA. Everything is single-threaded: there is no
//! background sampling thread, because a thread that wakes up on a timer costs
//! more than letting the existing message loop do the work.

use crate::config::{Config, TraySource, MAX_INTERVAL_S, MIN_INTERVAL_S};
use crate::graph;
use crate::history::{History, CAPACITY, NO_VALUE};
use crate::sensors::{driver::DriverStatus, Kind, Sensors};
use crate::theme;

/// Discrete slider stops, in seconds. Discrete beats a continuous 1..300
/// range: the useful values are not evenly spread, and every stop lands on a
/// number worth choosing.
pub const STEPS: [u32; 13] = [1, 2, 5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 300];

pub struct App {
    pub config: Config,
    pub sensors: Sensors,
    /// One ring buffer per channel, index-aligned with `sensors.channels`.
    pub histories: Vec<History>,
    /// Scratch for the most recent sample, reused every tick.
    pub latest: Vec<i16>,
    /// Seconds represented by each stored sample, index-aligned with the
    /// histories.
    ///
    /// The sampling rate changes while the flyout is open, so the chart cannot
    /// assume a fixed cadence -- a window of 240 samples might be two hours of
    /// background sampling or four minutes of live sampling, or a mix. Storing
    /// the interval alongside each sample makes the time axis exact for two
    /// bytes a sample instead of guessing.
    pub spans: History,
    pub popup: windows_sys::Win32::Foundation::HWND,
    /// True while the user is dragging the interval slider.
    pub dragging: bool,
}

impl App {
    pub fn new() -> Self {
        let config = Config::load();
        let sensors = Sensors::probe();
        let n = sensors.channels.len();
        Self {
            config,
            sensors,
            histories: (0..n).map(|_| History::new()).collect(),
            spans: History::new(),
            latest: vec![NO_VALUE; n],
            popup: std::ptr::null_mut(),
            dragging: false,
        }
    }

    /// Take one reading from every sensor and append it to the history.
    ///
    /// `interval_s` is the cadence this sample was taken at, recorded so the
    /// chart can report a truthful time span across rate changes.
    pub fn sample(&mut self, interval_s: u32) {
        self.sensors.sample_into(&mut self.latest);
        for (i, v) in self.latest.iter().enumerate() {
            if let Some(h) = self.histories.get_mut(i) {
                h.push(*v);
            }
        }
        self.spans.push(interval_s.clamp(1, i16::MAX as u32) as i16);
    }

    /// Which channel the tray icon is currently showing.
    pub fn tray_channel(&self) -> Option<usize> {
        match self.config.tray_source {
            TraySource::HottestOverall => self.sensors.hottest(&self.latest),
            TraySource::Cpu => self.sensors.first_of(Kind::Cpu),
            TraySource::Gpu => self.sensors.first_of(Kind::Gpu),
        }
    }

    /// (icon text, icon colour, tooltip) for the current state.
    pub fn tray_display(&self) -> (String, u32, String) {
        let Some(idx) = self.tray_channel() else {
            let tip = match self.sensors.cpu_status {
                DriverStatus::Ready => "tempmanager - no sensors found".to_string(),
                s => format!("tempmanager - {}", s.message()),
            };
            return ("--".to_string(), theme::TEXT_DIM, tip);
        };

        let v = self.latest.get(idx).copied().unwrap_or(NO_VALUE);
        let ch = &self.sensors.channels[idx];
        let color = if v == NO_VALUE {
            theme::TEXT_DIM
        } else {
            theme::status_color(v, ch.warn, ch.hot)
        };

        // The tooltip carries every channel, so hovering answers the question
        // without needing to open the popup at all.
        let mut tip = String::with_capacity(64);
        for (i, c) in self.sensors.channels.iter().enumerate() {
            if i > 0 {
                tip.push('\n');
            }
            let val = self.latest.get(i).copied().unwrap_or(NO_VALUE);
            tip.push_str(&format!(
                "{}: {}",
                c.label,
                graph::format_temp(val, self.config.fahrenheit, true)
            ));
        }
        if tip.is_empty() {
            tip.push_str("tempmanager");
        }

        (
            graph::format_tray(v, self.config.fahrenheit),
            color,
            tip,
        )
    }

    /// Index into STEPS for the configured interval, snapping to the nearest.
    pub fn step_index(&self) -> usize {
        STEPS
            .iter()
            .enumerate()
            .min_by_key(|(_, s)| (**s as i32 - self.config.interval_s as i32).abs())
            .map(|(i, _)| i)
            .unwrap_or(6)
    }

    pub fn set_step(&mut self, i: usize) -> bool {
        let v = STEPS[i.min(STEPS.len() - 1)].clamp(MIN_INTERVAL_S, MAX_INTERVAL_S);
        if v == self.config.interval_s {
            return false;
        }
        self.config.interval_s = v;
        true
    }

    /// How many samples the graph shows, and the wall-clock seconds that covers.
    ///
    /// The span is summed from the recorded per-sample intervals rather than
    /// assuming the current rate applied throughout.
    pub fn graph_window(&self) -> (usize, u32) {
        let window = CAPACITY.min(240);
        let seconds: u32 = self
            .spans
            .iter_recent(window)
            .filter(|s| *s != NO_VALUE)
            .map(|s| s.max(0) as u32)
            .sum();
        (window, seconds.max(1))
    }

    pub fn series_color(&self, i: usize) -> u32 {
        theme::series_color(i)
    }
}
