//! Fixed-capacity ring buffers for sample history.
//!
//! Sized at compile time and allocated once at startup, so sampling never
//! touches the allocator and the working set never grows over uptime.

/// Samples retained per sensor. At the 30 s default that is ~10 hours of
/// history for 1.4 KB per sensor.
pub const CAPACITY: usize = 1200;

/// Sentinel for "no reading at this slot" (sensor absent or read failed).
pub const NO_VALUE: i16 = i16::MIN;

/// Temperatures are stored as tenths of a degree Celsius in an i16: enough
/// range for -3276.8..3276.7 C and exact for the 0.125 C steps the SMU
/// reports once rounded. Half the memory of f32, and no float in the buffer.
#[derive(Clone)]
pub struct History {
    buf: Box<[i16; CAPACITY]>,
    /// Index the next sample will be written to.
    head: usize,
    /// Number of valid samples, saturating at CAPACITY.
    len: usize,
}

impl History {
    pub fn new() -> Self {
        Self { buf: Box::new([NO_VALUE; CAPACITY]), head: 0, len: 0 }
    }

    pub fn push(&mut self, deci_c: i16) {
        self.buf[self.head] = deci_c;
        self.head = (self.head + 1) % CAPACITY;
        if self.len < CAPACITY {
            self.len += 1;
        }
    }

    pub fn len(&self) -> usize {
        self.len
    }

    #[allow(dead_code)]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// Most recent sample, if any and if it is a real reading.
    #[allow(dead_code)]
    pub fn last(&self) -> Option<i16> {
        if self.len == 0 {
            return None;
        }
        let i = (self.head + CAPACITY - 1) % CAPACITY;
        let v = self.buf[i];
        (v != NO_VALUE).then_some(v)
    }

    /// Oldest-to-newest iterator over the last `n` samples.
    pub fn iter_recent(&self, n: usize) -> impl Iterator<Item = i16> + '_ {
        let n = n.min(self.len);
        let start = (self.head + CAPACITY - n) % CAPACITY;
        (0..n).map(move |k| self.buf[(start + k) % CAPACITY])
    }

    /// (min, max) over the last `n` real samples.
    pub fn range_recent(&self, n: usize) -> Option<(i16, i16)> {
        let mut lo = i16::MAX;
        let mut hi = i16::MIN;
        let mut any = false;
        for v in self.iter_recent(n) {
            if v == NO_VALUE {
                continue;
            }
            any = true;
            if v < lo { lo = v; }
            if v > hi { hi = v; }
        }
        any.then_some((lo, hi))
    }
}
