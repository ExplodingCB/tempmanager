//! NVMe / SATA drive temperatures.
//!
//! `IOCTL_STORAGE_QUERY_PROPERTY` with `StorageDeviceTemperatureProperty` is
//! serviced by the Windows storage stack, so this needs no kernel driver and
//! no elevation -- the handle is opened with zero desired access, which is
//! enough for a property query.
//!
//! Structures are declared locally rather than pulled from a windows-sys
//! feature so this module depends only on CreateFileW/DeviceIoControl.

use std::ffi::c_void;
use windows_sys::Win32::Foundation::{CloseHandle, HANDLE, INVALID_HANDLE_VALUE};
use windows_sys::Win32::Storage::FileSystem::{
    CreateFileW, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ, FILE_SHARE_WRITE, OPEN_EXISTING,
};
use windows_sys::Win32::System::IO::DeviceIoControl;

// CTL_CODE(IOCTL_STORAGE_BASE 0x2D, 0x0500, METHOD_BUFFERED, FILE_ANY_ACCESS)
const IOCTL_STORAGE_QUERY_PROPERTY: u32 = 0x002D_1400;

const STORAGE_DEVICE_PROPERTY: u32 = 0;
const STORAGE_DEVICE_TEMPERATURE_PROPERTY: u32 = 52;
const PROPERTY_STANDARD_QUERY: u32 = 0;

/// Highest \\.\PhysicalDriveN index we bother probing at startup.
const MAX_DRIVES: u32 = 16;

#[repr(C)]
struct StoragePropertyQuery {
    property_id: u32,
    query_type: u32,
    additional_parameters: [u8; 4],
}

#[repr(C)]
struct StorageTemperatureInfo {
    index: u16,
    temperature: i16,
    over_threshold: i16,
    under_threshold: i16,
    over_threshold_changed: u8,
    under_threshold_changed: u8,
}

#[repr(C)]
struct StorageTemperatureDataDescriptor {
    version: u32,
    size: u32,
    critical_temperature: i16,
    warning_temperature: i16,
    info_count: u16,
    reserved0: [u8; 2],
    reserved1: [u32; 2],
    // Followed by info_count * StorageTemperatureInfo.
}

pub struct Drive {
    index: u32,
    pub label: String,
}

fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(std::iter::once(0)).collect()
}

fn open_drive(index: u32) -> Option<HANDLE> {
    let path = wide(&format!("\\\\.\\PhysicalDrive{index}"));
    let h = unsafe {
        CreateFileW(
            path.as_ptr(),
            0, // property queries need no read/write access, so no elevation
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            std::ptr::null(),
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            std::ptr::null_mut(),
        )
    };
    (h != INVALID_HANDLE_VALUE && !h.is_null()).then_some(h)
}

fn query(h: HANDLE, property_id: u32, out: &mut [u8]) -> Option<u32> {
    let q = StoragePropertyQuery {
        property_id,
        query_type: PROPERTY_STANDARD_QUERY,
        additional_parameters: [0; 4],
    };
    let mut returned: u32 = 0;
    let ok = unsafe {
        DeviceIoControl(
            h,
            IOCTL_STORAGE_QUERY_PROPERTY,
            &q as *const _ as *const c_void,
            std::mem::size_of::<StoragePropertyQuery>() as u32,
            out.as_mut_ptr() as *mut c_void,
            out.len() as u32,
            &mut returned,
            std::ptr::null_mut(),
        )
    };
    (ok != 0).then_some(returned)
}

/// Pull the product ID out of a STORAGE_DEVICE_DESCRIPTOR blob.
fn product_name(buf: &[u8], returned: u32) -> Option<String> {
    if returned < 36 {
        return None;
    }
    let product_id_offset =
        u32::from_le_bytes([buf[16], buf[17], buf[18], buf[19]]) as usize;
    if product_id_offset == 0 || product_id_offset >= returned as usize {
        return None;
    }
    let tail = &buf[product_id_offset..returned as usize];
    let end = tail.iter().position(|&b| b == 0).unwrap_or(tail.len());
    let name = String::from_utf8_lossy(&tail[..end]).trim().to_string();
    (!name.is_empty()).then_some(name)
}

/// Probe every physical drive once at startup and keep the ones that actually
/// report a temperature, so the sample path never touches a dead handle.
pub fn detect() -> Vec<Drive> {
    let mut drives = Vec::new();
    for index in 0..MAX_DRIVES {
        let Some(h) = open_drive(index) else { continue };

        let mut temp_buf = [0u8; 512];
        let supports_temp = query(h, STORAGE_DEVICE_TEMPERATURE_PROPERTY, &mut temp_buf)
            .map(|n| parse_temperature(&temp_buf, n).is_some())
            .unwrap_or(false);

        let label = if supports_temp {
            let mut desc_buf = [0u8; 1024];
            query(h, STORAGE_DEVICE_PROPERTY, &mut desc_buf)
                .and_then(|n| product_name(&desc_buf, n))
                .unwrap_or_else(|| format!("Drive {index}"))
        } else {
            String::new()
        };

        unsafe { CloseHandle(h) };

        if supports_temp {
            drives.push(Drive { index, label: shorten(&label) });
        }
    }
    drives
}

fn parse_temperature(buf: &[u8], returned: u32) -> Option<i16> {
    let header = std::mem::size_of::<StorageTemperatureDataDescriptor>();
    if (returned as usize) < header {
        return None;
    }
    let desc = unsafe { &*(buf.as_ptr() as *const StorageTemperatureDataDescriptor) };
    if desc.info_count == 0 {
        return None;
    }

    let entry = std::mem::size_of::<StorageTemperatureInfo>();
    if (returned as usize) < header + entry {
        return None;
    }

    // Index 0 is the composite/primary sensor on every NVMe device.
    let info = unsafe { &*(buf.as_ptr().add(header) as *const StorageTemperatureInfo) };

    // The storage stack reports whole degrees Celsius. 0 usually means
    // "not reported" rather than a genuine 0 C on a running drive.
    let c = info.temperature;
    (c > 0 && c < 150).then_some(c * 10)
}

impl Drive {
    /// Current temperature in tenths of a degree Celsius.
    ///
    /// The handle is opened per read rather than held open for the process
    /// lifetime, so the app never keeps a reference that would block a drive
    /// from sleeping or being safely removed.
    pub fn read(&self) -> Option<i16> {
        let h = open_drive(self.index)?;
        let mut buf = [0u8; 512];
        let result = query(h, STORAGE_DEVICE_TEMPERATURE_PROPERTY, &mut buf)
            .and_then(|n| parse_temperature(&buf, n));
        unsafe { CloseHandle(h) };
        result
    }
}

/// Trim vendor noise so labels fit the popup's column.
fn shorten(name: &str) -> String {
    let s = name.trim();
    if s.len() <= 22 {
        s.to_string()
    } else {
        format!("{}...", &s[..19])
    }
}
