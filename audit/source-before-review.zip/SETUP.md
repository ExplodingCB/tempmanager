# Enabling CPU temperature

GPU and drive temperatures work out of the box. CPU does not, and this explains
why, what your options are, and what I deliberately did not do for you.

## Why CPU temperature is hard on Ryzen

On AMD Zen there is no user-mode path to the die temperature. The value lives
behind the SMU's System Management Network, reached by writing an address to PCI
config offset `0x60` of device `00:00.0` and reading the result from `0x64`. PCI
config space is accessed through I/O ports `0xCF8`/`0xCFC`, and those
instructions are ring-0 only.

I verified there is no fallback on your machine:

```
Get-CimInstance -Namespace root/WMI -ClassName MSAcpi_ThermalZoneTemperature
  -> "Not supported"
```

This is not a limitation of this app. HWMonitor, HWiNFO, LibreHardwareMonitor
and Core Temp all ship a kernel driver for exactly this reason.

## The blocker on this machine

Your system has **Memory Integrity (HVCI) enabled**:

```
SecurityServicesRunning           : {2}
VirtualizationBasedSecurityStatus : 2
```

HVCI enforces Microsoft's vulnerable-driver blocklist. **WinRing0** — the driver
this class of tool uses, including LibreHardwareMonitor and FanControl — is on
that blocklist. With Memory Integrity on, it will not load.

So enabling CPU temperature needs **two** things, not one:

1. A WinRing0-compatible `.sys` on disk.
2. Memory Integrity turned off.

Admin rights alone are not enough.

## What the app already does

`src/sensors/driver.rs` is a complete client for this interface. It will:

- attach to a `WinRing0_1_2_0` service that is already running, or
- register and start one from `WinRing0x64.sys` placed **next to
  `tempmanager.exe`**, then
- read `ZEN_REPORTED_TEMP_CTRL_BASE` (`0x00059800`) and the per-CCD registers,
  decode them, and light up the CPU row.

The register offsets and conversion arithmetic follow the Linux `k10temp` driver
(`drivers/hwmon/k10temp.c`), cross-checked against LibreHardwareMonitor's
`Amd17Cpu.cs`. Your 9800X3D is family `0x1A`, model `0x44`, which maps to CCD
offset `0x308` — both sources agree on this.

The flyout reports which of the three failure states it is in rather than
silently hiding the row:

| Message | Meaning |
|---|---|
| `driver not installed - see SETUP.md` | No running service and no `.sys` found |
| `run once as administrator to install` | `.sys` present, but registering the service needs elevation |
| `driver blocked - Memory Integrity is on` | Service registered but the kernel refused to load the image |

## What I did not do, and why

**I did not download or install a kernel driver for you.** A ring-0 driver can
do anything to your system, WinRing0 specifically carries a known privilege-
escalation vulnerability (CVE-2020-14979) — which is why it is blocklisted — and
Defender flags it as `HackTool:Win32/WinRing0`.

**I did not turn off Memory Integrity for you.** That is a real reduction in your
system's security posture, and it protects against exactly the class of driver
you would be installing. That trade is yours to make, not mine.

Both are reversible, and plenty of people running enthusiast hardware make this
trade knowingly. I just want you making it deliberately.

## If you decide to proceed

1. **Get the driver.** It ships inside the
   [LibreHardwareMonitor](https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases)
   release archive — extract `WinRing0x64.sys` and put it next to
   `tempmanager.exe`. Verify the signature before trusting it:

   ```bash
   Get-AuthenticodeSignature .\WinRing0x64.sys | Format-List
   ```

2. **Turn off Memory Integrity.** Windows Security → Device security → Core
   isolation → Memory integrity → Off. This needs a reboot.

3. **Run `tempmanager.exe` as administrator once.** It registers the driver as a
   demand-start service; after that, normal launches attach to it without
   elevation.

4. **Confirm it worked:**

   ```bash
   tempmanager.exe --probe
   ```

   `probe.txt` should now show a `[CPU ]` row.

## Status on this machine: Option B is installed and working

```
cpu backend : ready
cpu source  : AMD Ryzen Master SDK
[CPU ] Ryzen 7 9800X3D          60.4°
```

Memory Integrity is still **on**. No WinRing0, nothing disabled.

What is installed:

| | |
|---|---|
| SDK | `C:\Program Files\AMD\RyzenMasterMonitoringSDK` (3.1.1.5478) |
| Driver | `AMDRyzenMasterDriverV32`, auto-start, WHQL-signed, currently running |
| Binding | `src/sensors/ryzen_sdk.rs`, pure Rust, no C++ shim, no MSVC |

### The one catch: it needs an elevated token

AMD's `Platform.dll` refuses to initialise for a non-elevated caller **even
when its driver service is already running** — I confirmed the service was
`Running` and `Automatic` and an unelevated `Init()` still returned false. This
is the same restriction Ryzen Master itself has, and there is no way around it
from user mode.

Unelevated, the app still runs and shows GPU and drive temperatures; the CPU row
reports `run as administrator for CPU temps`.

Two ways to get the CPU row:

1. **Right-click the tray icon → "Restart as administrator."** Appears only when
   it would actually change what can be read.
2. **Tick "Start with Windows" while running elevated.** That registers a logon
   scheduled task with `/rl highest` instead of a Run-key entry, so the app
   starts elevated at every login **without** a UAC prompt. A Run-key entry
   cannot do that, which is why the autostart path changed.

### A note on how the SDK got installed

The installer's silent mode registered the product but rolled back without
deploying files. The cause was a launch condition in AMD's own MSI:

```
CONDITION : QTLAUNCH = 1
MESSAGE   : Installation of [ProductName] from extracted binaries is prohibited.
```

That is a guard against installing from a partially extracted payload; the
install was completed by passing `QTLAUNCH=1`, which is the property AMD's own
bootstrapper sets. Nothing was patched or bypassed beyond that flag.

## Option B in detail: AMD Ryzen Master Monitoring SDK (keeps Memory Integrity on)

AMD's own driver is WHQL-signed and is **not** blocklisted, so it loads fine
under HVCI. This is the only route to CPU temperature that does not ask you to
weaken your system.

Confirmed viable for your hardware: **SDK 3.0.x supports Zen 5 / Ryzen 9000**,
and Ryzen Master 3.0 is built specifically for that generation.

The app is already structured for it. `src/sensors/cpu.rs` defines a
`CpuBackend` trait; `WinRing0Backend` implements it today, and `cpu::open()`
prefers the SDK whenever it is available. Nothing outside `src/sensors/` needs
to change when the SDK backend lands.

### What is still needed, and why it is blocked on you

The SDK is a **C++ virtual-interface API**, not a flat C one:

```cpp
IPlatform& rPlatform = GetPlatform();
rPlatform.Init();
IDeviceManager& rDeviceManager = rPlatform.GetIDeviceManager();
ICPUEx* obj = (ICPUEx*)rDeviceManager.GetDevice(dtCPU, 0);
obj->GetCPUParameters(stData);   // stData.dTemperature
```

Binding that from Rust means reproducing the vtable slot order of `IPlatform`,
`IDeviceManager` and `ICPUEx` exactly, plus the `CPUParameters` layout. A wrong
slot index does not give a wrong number — it gives an indirect call into
whatever else sits at that offset, quite possibly a destructor. So the ordering
has to be read off AMD's headers rather than guessed.

Those headers are **not redistributable**. Every public project that binds this
SDK ships a placeholder telling you to copy them out of your own install — the
C# bindings literally have a file named `COPY_INCLUDES_FROM_RM_SDK_HERE.txt`.
There is no copy I can legitimately obtain without the SDK being installed here.

### To unblock it

1. Download the **AMD Ryzen Master Monitoring SDK** from
   [amd.com/en/developer/ryzen-master-monitoring-sdk.html](https://www.amd.com/en/developer/ryzen-master-monitoring-sdk.html)
   and install it. It brings `AMDRyzenMasterDriver.sys` (WHQL-signed),
   `PlatformSDKAPI.dll`, and the `include/` headers.

2. Confirm the app can see it:

   ```bash
   tempmanager.exe --probe
   ```

   `probe.txt` reports the SDK's install path, DLL and header directory, so we
   can both see exactly what landed.

Once the headers are on disk I can read the real declaration order and write the
binding directly in Rust — no C++ shim and no Visual Studio, which keeps your
GNU-only toolchain intact.

I have not installed the SDK for you, for the same reason I did not install
WinRing0: it puts a kernel-mode driver on your system, and that should be your
call, not a side effect of a build step.
